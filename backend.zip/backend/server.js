// backend/server.js
import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

// ✅ simple route to confirm backend works
app.get("/", (req, res) => {
  res.send("Cadi backend is running successfully 🚀");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Backend live on port ${PORT}`));
